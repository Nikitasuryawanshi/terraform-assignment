# DevOps Project
DevOps Project

Created AWS services through Terraform code

Created Ansible Inventory and Playbook file to Install Docker on Jenkins and App hosts

Created Jenkins Build Pipeline
